#!/bin/sh
export DATABASE_PATH="/home/bbs/bbs.db"
exec /usr/bin/python3 /home/bbs/bbs.py
